#pragma once

#include <vector>
#include <string>
#include <time.h>
#include <stdlib.h>
#include <sstream>
#include <cv.h>
#include <highgui.h>

#include "stdafx.h"

#include "global.h"
#include "data.h"
#include "filter.h"
#include "camera.h"
#include "cleyecameracapture.h"

#include "step.h"
#include "parameter.h"

#include "ThresholdFilter.h"
#include "EmptyFilter.h"
#include "LabThresholdFilter.h"
#include "AddFilter.h"
#include "BlobFilter.h"
#include "FastCornerFilter.h"
#include "SmoothFilter.h"
#include "ErosionFilter.h"
#include "DilationFilter.h"


int MAX_STEPS=9;
int currentScreen;
std::vector<Step*> screenSteps;
/*std::vector<std::string> strFilterList;
std::vector<Filter*> filterList;
std::vector<std::string> strSourceList;*/


void saveScreenshot(IplImage* img);
void writeAVI(IplImage* img);
void prepareAVI(int fps);
bool recordingAVI;

CvFont titleFont;
CvFont menuFont;
CvFont menuFontBold;
CvScalar green;
CvScalar black;

#define KEY_LEFT 2424832 //29
#define KEY_RIGHT 2555904 //28
#define KEY_UP 2490368 //30
#define KEY_DOWN 2621440 //31
#define KEY_SHIFT_LEFT 2359296
#define KEY_SHIFT_RIGHT 2293760
#define KEY_SHIFT_UP 2162688
#define KEY_SHIFT_DOWN 2228224