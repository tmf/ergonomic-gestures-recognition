#include "FastCornerFilter.h"

FastCornerFilter::FastCornerFilter(void)
{
	name = "Fast Corner Filter";
	sourceCount=1;
    params.push_back(new Parameter(0.0f, 20.0f, 255.0f));
	
}

FastCornerFilter::~FastCornerFilter(void)
{
}

FastCornerFilter* FastCornerFilter::clone(){
	FastCornerFilter *fcf = new FastCornerFilter();
    fcf->params.clear();
    for(int i=0;i<(int)params.size();i++)
        fcf->params.push_back(new Parameter(this->params[i]));
    return fcf;
}
IplImage* FastCornerFilter::filter(std::vector<IplImage*> images){
	IplImage *img = 0;
	if(images.size()>0)
		img = images[0];
	
	char *strImg = new char[32];
	sprintf(strImg, "fastcorner_%d", step);
	StorageObject *so_thresh = getStorageObject(std::string(strImg));
    if(so_thresh->data==0)
		so_thresh->data = cvCreateImage(cvGetSize(img), IPL_DEPTH_8U, 1);
	IplImage *thresh = (IplImage *)so_thresh->data;
	if(img->nChannels>1)
		cvCvtColor(img, thresh, CV_RGB2GRAY);
	else
		cvCopy(img, thresh);
	Parameter *pThreshold = params[0];
	
	if(pThreshold != 0 ){
		CvPoint* corners;
		int numCorners;
		std::vector<std::vector<CvPoint *> > blobs;

		cvCornerFast(thresh, 20, 9, 0, &numCorners, & corners);
		for(int i=1; i < numCorners; i++ ) 
		{

			//cvLine(img, cvPoint(corners[i-1].x, corners[i-1].y), cvPoint(corners[i].x, corners[i].y), CV_RGB(255, 0, 0));
			cvLine( img, 
					cvPoint( corners[i].x-1, corners[i].y ), 
					cvPoint( corners[i].x+1, corners[i].y ), 
					CV_RGB(0,0,255) );
			cvLine( img, 
					cvPoint( corners[i].x, corners[i].y-1 ), 
					cvPoint( corners[i].x, corners[i].y+1 ), 
					CV_RGB(0,0,255) );
			
			/*for(int j=i; j<numCorners;j++){
				int dx = corners[i].x - corners[j].x;
				int dy = corners[i].y - corners[j].y;
				double hoi = dx*dx +dy*dy;
				double dist = sqrt(hoi);
			}*/
		}
	}
	return img;

}