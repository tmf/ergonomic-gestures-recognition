#include "tracker.h"

void init(){
    cvStartWindowThread();
    cvNamedWindow("Calibration", 0);
    //cvNamedWindow("Screen");
    cvResizeWindow("Calibration", 640, 480);
    //cvResizeWindow("Screen", 640, 480);
    cvMoveWindow("Calibration", 0, 0);
    //cvMoveWindow("Screen", 640, 0);
	
    //capture = cvCreateCameraCapture(0);
    
    //frame = cvQueryFrame(capture);
	//frame = cvCreateImage(cvSize(640, 480), IPL_DEPTH_8U, 4);
	//lab = cvCreateImage(cvSize(640, 480), IPL_DEPTH_8U, 3);
	//mask = cvCreateImage(cvSize(640, 480), IPL_DEPTH_8U, 3);
	//while(!ready(ps3_eye_left)) cvWaitKey(50);
	//cvCopy(ps3_eye_left->pCapImage, frame);
    //img = cvCreateImage(cvSize(frame->width, frame->height ),frame->depth, frame->nChannels);

    cvInitFont(&titleFont, CV_FONT_HERSHEY_SIMPLEX, 0.8, 0.8, 0.0, 2,8);
    cvInitFont(&menuFont, CV_FONT_HERSHEY_SIMPLEX, 0.5, 0.5, 0.0, 1,8);
    cvInitFont(&menuFontBold, CV_FONT_HERSHEY_SIMPLEX, 0.5, 0.5, 0.0, 2,8);
	camera_setup();
	if(false){ //config file valid and existing
		screenSteps = restore();
		for(int i=0; i<screenSteps.size();i++){
			std::stringstream str;
			str<<"Screen "<<(i+1);
			std::string name(str.str());
			strSourceList.push_back(name);
		}
	}else{
		for(int i=0; i<MAX_STEPS;i++){
			Step *s = new Step(i);
			screenSteps.push_back(s);
		}
	}
	
	
    strFilterList.push_back("Empty Filter");
    strFilterList.push_back("Threshold Filter");
    strFilterList.push_back("Lab Threshold Filter");
	strFilterList.push_back("Add Filter");
	strFilterList.push_back("Blob Filter");
	strFilterList.push_back("Fast Corner Filter");
	strFilterList.push_back("Smooth Filter");
	strFilterList.push_back("Erosion Filter");
	strFilterList.push_back("Dilation Filter");

    filterList.push_back(new EmptyFilter());
    filterList.push_back(new ThresholdFilter());
	filterList.push_back(new LabThresholdFilter());
	filterList.push_back(new AddFilter());
	filterList.push_back(new BlobFilter());
	filterList.push_back(new FastCornerFilter());
	filterList.push_back(new SmoothFilter());
	filterList.push_back(new ErosionFilter());
	filterList.push_back(new DilationFilter());

    green = CV_RGB(100,200,40);
    black = CV_RGB(0,0,0);
}