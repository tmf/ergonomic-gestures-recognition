#include <vector>
#include <string.h>
#include "filter.h"
#include "cleyecameracapture.h"
#include "Step.h"

extern CvFont titleFont;
extern CvFont menuFont;
extern CvFont menuFontBold;

extern std::vector<std::string> strFilterList;
extern std::vector<Filter*> filterList;
extern std::vector<std::string> strSourceList;
extern CvScalar green;
extern CvScalar black;

extern StorageObject* getStorageObject(std::string &name);

extern int currentScreen;
extern int MAX_STEPS;
extern std::vector<Step*> screenSteps;

extern CLEyeCameraCapture *ps3_eye_left;
extern CLEyeCameraCapture *ps3_eye_right;

extern double totalExecutionTime;

extern void saveScreenshot(IplImage* img);
extern void writeAVI(IplImage* img);
extern void prepareAVI(int fps);
extern bool recordingAVI;