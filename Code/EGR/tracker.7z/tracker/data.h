#include "step.h"
#include <vector>
#include <time.h>
#include "global.h"

enum SO_PERSISTANCE { SOP_LOOP, SOP_INFINITE};

struct StorageObject {
    void* data;
	std::string name;
	SO_PERSISTANCE persistance;
};

static std::vector<StorageObject*> storage;
#include "BoostDefines.hpp"
#include <boost/serialization/vector.hpp>

// include headers that implement a archive in simple text format 
#include <boost/archive/text_oarchive.hpp> 
#include <boost/archive/text_iarchive.hpp>
//#include <iostream>
#include <fstream>

void save(const std::vector<Step *> vec_steps);
std::vector<Step *>  restore();

#if defined(_MSC_VER) || defined(_MSC_EXTENSIONS)
  #define DELTA_EPOCH_IN_MICROSECS  11644473600000000Ui64
#else
  #define DELTA_EPOCH_IN_MICROSECS  11644473600000000ULL
#endif

int _gettimeofday(struct timeval *tv, struct timezone *tz);
float milliseconds();
double totalExecutionTime;