#include "BlobFilter.h"
#include "BlobResult.h"
#include "tracker.h"

BlobFilter::BlobFilter(void)
{
	name = "Blob Filter";
	sourceCount=1;
    params.push_back(new Parameter(0.0f, 100.0f, 255.0f));
	params.push_back(new Parameter(0.0f, 1.0f, 255.0f));
}

BlobFilter::~BlobFilter(void)
{
}
BlobFilter* BlobFilter::clone(){
	BlobFilter *bf = new BlobFilter();
	bf->blobs.ClearBlobs();
    bf->params.clear();
    for(int i=0;i<(int)params.size();i++)
        bf->params.push_back(new Parameter(this->params[i]));
    return bf;
}
IplImage* BlobFilter::filter(std::vector<IplImage*> images){
	IplImage *img = 0;
	if(images.size()>0)
		img = images[0];
	
	char *strThreshold = new char[32];
	sprintf(strThreshold, "blobthreshold_%d", step);
	StorageObject *so_thresh = getStorageObject(std::string(strThreshold));
    if(so_thresh->data==0)
		so_thresh->data = cvCreateImage(cvGetSize(img), IPL_DEPTH_8U, 1);
	IplImage *thresh = (IplImage *)so_thresh->data;
	if(img->nChannels>1)
		cvCvtColor(img, thresh, CV_RGB2GRAY);
	Parameter *pThreshold = params[1];
	Parameter *pBlobsize = params[0];
	if(pThreshold != 0 && pBlobsize != 0){
		cvThreshold(thresh, thresh, pThreshold->getVal(), 255, CV_THRESH_BINARY);
		//cvErode(thresh, thresh);
		//cvDilate(thresh, thresh);
		
// find blobs in image
		blobs = CBlobResult( thresh, NULL, 0 );
		//blobs.Filter( blobs, B_INCLUDE, CBlobGetArea(), B_LESS,  200000.0f);
		blobs.Filter( blobs, B_EXCLUDE, CBlobGetArea(), B_LESS,  pBlobsize->getVal());

		CBlob *currentBlob;
		int n = blobs.GetNumBlobs();
		for (int i = 0; i < blobs.GetNumBlobs(); i++ )
		{
			currentBlob = blobs.GetBlob(i);
			//printf("blob %d size: %f\n", i, (float)currentBlob->Area());
			
			currentBlob->FillBlob( img, CV_RGB(255,0,255));
			//CvRect r = currentBlob->GetBoundingBox();
			/*CvBox2D b = currentBlob->GetEllipse();
			b.angle += 90;
			
			
			cvEllipseBox(img, b, CV_RGB(0, 255, 255));*/
			//cvRectangle(img, cvPoint(r.x, r.y), cvPoint(r.x+r.width, r.y + r.height), CV_RGB(0, 0, 255));
		}
	}
	return img;
}