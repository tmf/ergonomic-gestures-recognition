#include "tracker.h"

void save(const std::vector<Step *> vec_steps){
	std::ofstream ofs("steps.config");
	// save data to archive 
	{
		boost::archive::text_oarchive oa(ofs); 
		// write class instance to archive 
		oa << vec_steps; 
		// archive and stream closed when destructors are called
	}
}
std::vector<Step *>  restore(){
	std::vector<Step *> vec_steps;
	
	std::ifstream ifs("steps.config");
	boost::archive::text_iarchive ia(ifs);
	ia >> vec_steps;
	return vec_steps;
}

StorageObject* getStorageObject(std::string &name){
    StorageObject* result = 0;
	
    for(int i=0;i<(int)storage.size();i++){
		//std::cout << "Comparing " << storage[i]->name << " with " << name << ": " << storage[i]->name.compare(name) << std::endl;
		if(storage[i]->name.compare(name)==0){
        //if(strcmp(storage[i]->name, name)==0){
            result = storage[i];
            break;
        }
    }
    if(result==0){
        result = new StorageObject();
        //result->name = new char[32];
		std::string str (name);
		result->name = str.c_str();
		//strcpy(result->name, name);
        result->data =0;
		result->persistance = SOP_INFINITE;
        storage.push_back(result);
    }
    return result;
}


int _gettimeofday(struct timeval *tv, struct timezone *tz)
{
  FILETIME ft;
  unsigned __int64 tmpres = 0;
  static int tzflag;
 
  if (NULL != tv)
  {
    GetSystemTimeAsFileTime(&ft);
 
    tmpres |= ft.dwHighDateTime;
    tmpres <<= 32;
    tmpres |= ft.dwLowDateTime;
 
    /*converting file time to unix epoch*/
    tmpres -= DELTA_EPOCH_IN_MICROSECS; 
    tmpres /= 10;  /*convert into microseconds*/
    tv->tv_sec = (long)(tmpres / 1000000UL);
    tv->tv_usec = (long)(tmpres % 1000000UL);
  }
 
  
 
  return 0;
}
float milliseconds(){
	struct timeval tmp;
	_gettimeofday(&tmp, NULL);
	float ms = (int)(tmp.tv_sec + tmp.tv_usec / 1000);
	return ms;
}