// tracker.cpp : Defines the exported functions for the DLL application.
//

#include "stdafx.h"
#include <string>
#include <vector>

struct Point
{
  int x;
  int y;
};
__declspec(dllexport) std::vector<Point> getBlobs(std::string s)
{
  struct Point p1, p2;
  p1.x = 10;
  p1.y = 50;
  p2.x = 100;
  p2.y = 30;
  std::vector<Point> v;
  v.push_back(p1);
  v.push_back(p2);
  return v;
}
std::string boostConfigurationFile;
__declspec(dllexport) void loadConfiguration(std::string s)
{
  boostConfigurationFile = s;
}
__declspec(dllexport) std::string startTracking()
{
  return boostConfigurationFile;
}
__declspec(dllexport) void stopTracking(std::string s)
{
}

__declspec(dllexport) std::vector<std::string>* test(std::string s){
  std::vector<std::string>* v = new std::vector<std::string>;
  v->push_back(s);
	return v;
}
